﻿using System;
using System.Numerics;

namespace determinant
{
    public class Determinant
    {
        public static BigInteger Calculate(string cond)
        {
            cond = cond.Replace(" ", "").Replace("\\\\", "\\");
            string[] tmp = cond.Split('\\');
            string[] tmptmp = new string[tmp.Length];
            BigInteger[,] det = new BigInteger[tmp.Length, tmp.Length];
            for (int i = 0; i < tmp.Length; i++)
            {
                tmptmp = tmp[i].Split('&');
                for (int j = 0; j < tmp.Length; j++)
                    det[i, j] = BigInteger.Parse(tmptmp[j]);
            }
            return(RecurCalc(det));
        }

        public static BigInteger RecurCalc(BigInteger[,] det)
        {
            int n = det.GetLength(0);
            BigInteger ans = 0;
            if (n == 1)
                return det[0, 0];
            BigInteger[,] tmp = new BigInteger[n - 1, n - 1];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n - 1; j++)
                {
                    for (int k = 0; k < n - 1; k++)
                    {
                        if (j < i)
                            tmp[j, k] = det[j, k + 1];
                        else
                            tmp[j, k] = det[j + 1, k + 1];
                    }
                }
                if (i % 2 == 0)
                    ans += det[i, 0] * RecurCalc(tmp);
                else
                    ans -= det[i, 0] * RecurCalc(tmp);
            }
            return ans;
        }
    }
}
