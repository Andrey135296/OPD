﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        public static void Main(string[] args)
        {
            string cond = Console.ReadLine();
            cond = "-16 & 2 & 5 & 5 & 8 & -2 & -12 & -12 \\ -11 & -2 & 14 & -16 & 13 & 11 & -17 & -3 \\ -7 & 17 & -15 & -13 & 12 & 9 & 15 & 1 \\ -4 & -8 & 2 & -17 & -12 & -11 & 9 & -12 \\ -12 & -14 & 10 & 8 & 6 & -6 & 17 & 13 \\ -10 & 8 & 6 & 9 & -8 & 10 & -16 & -10 \\ -17 & 9 & 14 & 3 & 6 & 13 & 10 & -7 \\ 4 & -14 & -10 & -2 & 14 & -13 & -18 & -18";
            cond = cond.Replace(" ", "").Replace("\\\\", "\\");
            string[] tmp = cond.Split('\\');
            string[] tmptmp = new string[tmp.Length];
            long[,] det = new long[tmp.Length, tmp.Length];
            for (int i=0; i<tmp.Length; i++)
            {
                tmptmp = tmp[i].Split('&');
                for (int j = 0; j < tmp.Length; j++)
                    det[i,j] = int.Parse(tmptmp[j]);
            }
            Console.WriteLine(calc(det));
            //return(calc(det));
        }

        public static long calc(long[,] det)
        {
            long n = (long)Math.Round(Math.Sqrt(det.Length), MidpointRounding.AwayFromZero);
            long ans = 0;
            if (n == 1)
                return det[0,0];
            long[,] tmp = new long[n - 1, n - 1];
            for (int i=0; i<n; i++)
            {
                for (int j=0; j<n-1; j++)
                {
                    for (int k=0; k<n-1; k++)
                    {
                        if (j < i)
                            tmp[j, k] = det[j, k+1];
                        else
                            tmp[j, k] = det[j + 1, k+1];
                    }
                }
                if (i % 2 == 0)
                    ans += det[i, 0]*calc(tmp);
                else
                    ans -= det[i, 0]*calc(tmp);
            }
            return ans;
        }
    }
}
