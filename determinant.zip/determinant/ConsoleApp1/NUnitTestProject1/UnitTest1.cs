using NUnit.Framework;
using System;
using System.Numerics;

namespace Tests
{
    [TestFixture]
    public class Tests
    {
        Random rnd = new Random();

        [Test] [Repeat(10000)]
        public void Tests2x2()
        {
            BigInteger a = rnd.Next(), b = rnd.Next(), c = rnd.Next(), d = rnd.Next();
            string s = String.Format("{0}&{1}\\\\{2}&{3}", a, b, c, d);
            BigInteger ans = determinant.Determinant.Calculate(s);
            Assert.AreEqual(ans, a * d - b * c);
        }

        [Test] [Repeat(10000)]
        public void Tests3x3()
        {
            BigInteger a = rnd.Next(), b = rnd.Next(), c = rnd.Next(), d = rnd.Next(), e = rnd.Next(), f = rnd.Next(), g = rnd.Next(), h = rnd.Next(), i = rnd.Next();
            string s = String.Format("{0}&{1}&{2}\\\\{3}&{4}&{5}\\\\{6}&{7}&{8}", a, b, c, d, e, f, g, h, i);
            BigInteger ans = determinant.Determinant.Calculate(s);
            Assert.AreEqual(ans, a * e * i + b * f * g + d * h * c - g * e * c - a * h * f - d * b * i);
        }

        [Test]
        [TestCase("2&2&3&4\\\\5&7&7&8\\\\9&10&12&12\\\\13&14&15&17", -45)]
        public void Test4x4(string s, long exp)
        {
            Assert.AreEqual(exp, (long)determinant.Determinant.Calculate(s));
        }

        [Test]
        [TestCase("-16 & 2 & 5 & 5 & 8 & -2 & -12 & -12 \\ -11 & -2 & 14 & -16 & 13 & 11 & -17 & -3 \\ -7 & 17 & -15 & -13 & 12 & 9 & 15 & 1 \\ -4 & -8 & 2 & -17 & -12 & -11 & 9 & -12 \\ -12 & -14 & 10 & 8 & 6 & -6 & 17 & 13 \\ -10 & 8 & 6 & 9 & -8 & 10 & -16 & -10 \\ -17 & 9 & 14 & 3 & 6 & 13 & 10 & -7 \\ 4 & -14 & -10 & -2 & 14 & -13 & -18 & -18", 62888756302)]
        public void Test8x8(string s, long exp)
        {
            Assert.AreEqual(exp, (long)determinant.Determinant.Calculate(s));
        }

        [Test]
        public void TestBig()
        {
            var exp = new BigInteger(10);
            for (int i = 0; i < 31; i++)
                exp = exp * 10;
            exp = exp - 1;
            exp = exp * exp;
            var s = "99999999999999999999999999999999 & 0 \\\\ 0 & 99999999999999999999999999999999";
            Assert.AreEqual(exp, determinant.Determinant.Calculate(s));
        }
    }
}